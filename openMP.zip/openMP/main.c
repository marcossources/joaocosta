#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include "sisRecom.h"

#define ALEATORIO ((double)random() / (double)RAND_MAX)


char nome_arquivo[100];
int numero_iteracoes,numeroFatores;
double alpha;
//linha e coluna da nossa matris// numero de elemento difernte da matriz de entrada 
int mU, nI, nnz;
//Funcao para inicializar a nossa matriz
void inicializarMatrix(double matrixA[mU][nI],int m, int n){	
	int i,j;
	for(i=0;i<m;i++){
	    for(j=0;j<n;j++){
			matrixA[i][j] = 0;	
		}
	}
}
//Funcao para imprimir a matrix
void imprimirMatriz(double matriz[mU][nI], int linhas, int colunas) {
    int i, j;
    for (i = 0; i < linhas; i++) {
        for (j = 0; j < colunas; j++) {
            printf("%.2lf\t", matriz[i][j]);
        }
        printf("\n");
    }
}


//Prencher a matrix de forma Aleatoria 
void preencherMatrizesAleatorias(double L[mU][numeroFatores],double R[numeroFatores][nI],int mU,int numeroFatores,int nI){
	srandom(0);
	int i,j;
	for(i = 0; i < mU; i++){
		for(j = 0; j < numeroFatores; j++){
			L[i][j] = ALEATORIO / (double) numeroFatores;
		}
	}
	
	for(i = 0; i < numeroFatores; i++){
		for(j = 0; j < nI; j++){
			R[i][j] = ALEATORIO / (double) numeroFatores;
		}
	}
	
}

//Multiplicacao da nossa matriz --- B=L*C
void MultiplicacaoDeMatriz(double matrixB[mU][nI], double L[mU][numeroFatores], double R[numeroFatores][nI], int mU, int nI, int numeroFatores) {
    int i, j, k;

	#pragma omp parallel for private(i,j,k)
    for (i = 0; i < mU; i++) {
        for (j = 0; j < nI; j++) {
            matrixB[i][j] = 0.0;
            for (k = 0; k < numeroFatores; k++) {
                matrixB[i][j] += L[i][k] * R[k][j];
            }
        }
    }
}


//Calcular no novo valor de L

void operacao(int numero_iteracoes,int numeroFatores,int nI, int mU,double L[mU][numeroFatores],double Lcopia[mU][numeroFatores], double alpha,  double C[mU][nI]) {
   
   for(int c=0;c< numero_iteracoes;c++){ 
	
	for (int i = 0; i < mU; i++) {
        for (int k = 0; k < numeroFatores; k++) {
            double soma = 0;
			 #pragma omp parallel for reduction(+:soma)
            for (int j = 0; j < nI; j++) {
                soma += C[i][j] / L[i][k];
            }
            Lcopia[i][k] = L[i][k] * L[i][k] - alpha * soma;
        }
    }
   }
}
void operacao1(int numero_iteracoes,int numeroFatores, int nI, int mU, double R[numeroFatores][nI], double Rcopia[numeroFatores][nI], double alpha,  double C[mU][nI]) {
   
   for(int c=0;c< numero_iteracoes;c++){ 
	
	for (int i = 0; i < mU; i++) {
        for (int k = 0; k < numeroFatores; k++) {
            double soma = 0;
			 #pragma omp parallel for reduction(+:soma)
            for (int j = 0; j < nI; j++) {
                soma += C[i][j] / R[i][k]; 
            }
            Rcopia[i][k] = R[i][k] * R[i][k] - alpha * soma;
        }
    }
   }
}
void calcularDiferencaAoQuadrado( int mU,int nI,double matrixA[mU][nI], double matrixB[mU][nI], double C[mU][nI]) {
	
    for (int i = 0; i < mU; i++) {
        for (int j = 0; j < nI; j++) {
            C[i][j] = (matrixA[i][j] - matrixB[i][j]) * (matrixA[i][j] - matrixB[i][j]);
        }
    }
}


//L[i][k]=Lcopia[i][k] -alpha*Σj(2*(A[i][j]-B[i][j])(-R[k][j]))

void recomendarItens(int mU, int nI, int numero_iteracoes, double matrixA[mU][nI], double matrixB[mU][nI]) {
    for (int i = 0; i < mU; i++) {
        double max_value = -1;
        int max_index = -1;
        for (int j = 0; j < nI; j++) {
            if (matrixA[i][j] == 0 && matrixB[i][j] > max_value) {
                max_value = matrixB[i][j];
                max_index = j;
            }
        }
        printf("%d\n", max_index);
		 
    }
}

void recomendarItens(int mU, int nI, double matrixA[mU][nI], double matrixB[mU][nI], const char *nome_arquivo) {
    FILE *arquivo_saida = fopen(nome_arquivo, "w");
    if (arquivo_saida == NULL) {
        printf("Erro ao abrir o arquivo de saída.\n");
        return;
    }
    
    for (int i = 0; i < mU; i++) {
        double max_value = -1;
        int max_index = -1;
        for (int j = 0; j < nI; j++) {
            if (matrixA[i][j] == 0 && matrixB[i][j] > max_value) {
                max_value = matrixB[i][j];
                max_index = j;
            }
        }
        fprintf(arquivo_saida, "%d\n", max_index);
    }
    
    fclose(arquivo_saida);
}


int main(){
    double tempo1, tempo2,t;
	
	tempo1 = omp_get_wtime();
	FILE *ficheiro;
	
		
	printf("\nDigite o nome do seu ficheiro :  ");
	scanf("%s",nome_arquivo);
	ficheiro = fopen(nome_arquivo, "r");
	
	if(ficheiro == NULL ){
		printf("\n\t erro ao abriro ficheiro .\n");
		return 1;
	}
	// Ler n�mero de itera��es
	fscanf(ficheiro,"%d\n",&numero_iteracoes);
	fscanf(ficheiro,"%lf\n",&alpha);
	fscanf(ficheiro,"%d\n",&numeroFatores);
	fscanf(ficheiro, "%d %d %d", &mU, &nI, &nnz);
	
	//Aqui estamos a cria a nossa matrixA
	double matrixA[mU][nI];
	double L[mU][numeroFatores];
	double R[numeroFatores][nI];
	double matrixB[mU][nI];
	double matrixC[mU][nI];
	double C[mU][nI];
	double matrixF[mU][nI];
	//Cpopias da matrix 
	double Lcopia[mU][numeroFatores];
	double Rcopia[numeroFatores][nI];

	//inicializando a nossa matrix
	inicializarMatrix(matrixA,mU,nI);	
	//fim da matrix
	int i,j;
	for (int i = 0; i < nnz; i++) {
    	int row, col;
    	double value;
    	fscanf(ficheiro, "%d %d %lf", &row, &col, &value);
    	matrixA[row][col] = value;
  	}
	
	//Motra a matria a
	printf("\n\n---  Matrix A  ----\n");
	imprimirMatriz(matrixA, mU,nI);
	preencherMatrizesAleatorias(L,R,mU,numeroFatores,nI);
	printf("\n\n---  Matrix L  ----\n");
	imprimirMatriz(L, mU,numeroFatores);
	printf("\n\n---  Matrix R  ----\n");
	imprimirMatriz(R,numeroFatores,nI);

	MultiplicacaoDeMatriz(matrixB,L,R,mU,nI,numeroFatores);
	
	//matrizCopiaL(Lcopia,L,mU, numeroFatores);
	
	//matrizCopiaR(Rcopia,R,numeroFatores ,nI);
	printf("\n Nova matriz L R\n");
	//recalcular L 

	calcularDiferencaAoQuadrado( mU,nI,matrixA, matrixB, C);
	operacao(numero_iteracoes,numeroFatores, nI, mU,L, Lcopia,alpha, C);
	operacao1(numero_iteracoes, numeroFatores, nI, mU, R, Rcopia, alpha,C);
	MultiplicacaoDeMatriz(matrixF,Lcopia,Rcopia,mU,nI,numeroFatores);

	

	

	printf("\n\n---  Matrix B  ----\n");
	imprimirMatriz(matrixB,mU,nI);
	
   
	
	printf("\n\n---  Saida final ----\n");
	printf("\n");
	imprimirMatriz(matrixF,mU,nI);
    recomendarItens(mU,nI,numero_iteracoes,matrixA, matrixF);
    recomendarItens1(mU, nI, matrixA, matrixB, "saida.txt");
    tempo2 = omp_get_wtime();
    printf("Tempo decorrido Funcao distancia %f s\n" , (tempo2 - tempo1));
	
	return 0;
}

