#ifndef FUNC_H
#define FUNC_H


int numeroPar(int n);
int sum(int num,int num1);



#endif
