#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

#define MAX_DOCUMENTO 10000
#define MAX_ASSUNTO 2000
#define MAX_ARMARIO 2000

double documentos[MAX_DOCUMENTO][MAX_ASSUNTO];
int documentos_armarios[MAX_DOCUMENTO];
double media_armarios[MAX_ARMARIO][MAX_ASSUNTO];


double t1, t2;

double distancia(double *doc, double *armarios, int s)
{
    double dist = 0;

     #pragma omp parallel for reduction(+:dist)
    for (int i = 0; i < s; i++)
    {
        dist += (doc[i] - armarios[i]) * (doc[i] - armarios[i]);
    }
    return dist;

}

void atribuicao_inicial(int d, int c)
{
	#pragma omp parallel for
    for (int i = 0; i < d; i++)
    {
        documentos_armarios[i] = i % c;
    }
}

void recalcula_media_armarios(int d, int c, int s)
{
    memset(media_armarios, 0, sizeof(media_armarios));
    int contagem[MAX_ARMARIO];
    memset(contagem, 0, sizeof(contagem));
    #pragma omp parallel for
    for (int i = 0; i < d; i++)
    {
        int armarios = documentos_armarios[i];
         #pragma omp atomic
        contagem[armarios]++;
        #pragma omp parallel for
        for (int j = 0; j < s; j++)
        {
        	 #pragma omp atomic
            media_armarios[armarios][j] += documentos[i][j];
        }
    }
    #pragma omp parallel for
    for (int i = 0; i < c; i++)
    {
        for (int j = 0; j < s; j++)
        {
            media_armarios[i][j] /= contagem[i];
        }
    }
}

int recalcula_atribuicao(int d, int c, int s)
{

    int mudancas = 0;
     #pragma omp parallel for reduction(+:mudancas)
    for (int i = 0; i < d; i++)
    {
        double *doc = documentos[i];
        double dist_min = INFINITY;
        int nova_armarios = -1;
          #pragma omp parallel for
        for (int j = 0; j < c; j++)
        {
            double dist = distancia(doc, media_armarios[j], s);
            if (dist < dist_min)
            {
                dist_min = dist;
                nova_armarios = j;
            }
        }
        if (documentos_armarios[i] != nova_armarios)
        {
            documentos_armarios[i] = nova_armarios;
            mudancas++;
        }
    }
    return mudancas;
}

int main()
{
    t1 = omp_get_wtime();
    int armarios, docs, assuntos, armarios_opcional, op = -1;
    char nome_arquivo[100];
    FILE *fp;

    printf("Digite o nome do arquivo: ");
    scanf("%s", nome_arquivo);
    fp = fopen(nome_arquivo, "r");

    if (fp == NULL)
    {
        printf("Erro ao abrir arquivo.\n");
        return 1;
    }

    printf("Deseja ler o numero de armarios agora? Sim(1) Nao(2): ");
    scanf("%d", &op);
    if (op == 1)
    {
        printf("Digite o numero de armarios: ");
        scanf("%d", &armarios_opcional);
    }

    fscanf(fp, "%d %d %d", &armarios, &docs, &assuntos);
    if (op == 1)
        armarios = armarios_opcional;

    for (int i = 0; i < docs; i++)
    {
        int id;

        fscanf(fp, "%d", &id);

        for (int j = 0; j < assuntos; j++)
        {
            fscanf(fp, "%lf", &documentos[id][j]);
        }
    }

    atribuicao_inicial(docs, armarios);
    int mudancas = 1;
    while (mudancas > 0)
    {
        recalcula_media_armarios(docs, armarios, assuntos);
        mudancas = recalcula_atribuicao(docs, armarios, assuntos);
    }

    FILE *saida = fopen("docs.out", "w");
    if (saida == NULL)
    {
        for (int i = 0; i < docs; i++)
        {
            printf("%d %d\n", i, documentos_armarios[i]);
        }
        printf("\n\nErro ao abrir arquivo de saída.\n");
        return 1;
    }

    for (int i = 0; i < docs; i++)
    {
        fprintf(saida, "%d %d\n", i, documentos_armarios[i]);

    }
    t2 = omp_get_wtime();
    printf("Tempo decorrido Funcao distancia %f s" , (t2 -t1));
    fclose(saida);
    fclose(fp);


    return 0;
}
